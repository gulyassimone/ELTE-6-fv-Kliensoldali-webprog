const Private = () => {
  return (
    <div>
      <h1>Szia, User!</h1>
      <div>Formázott tartalom</div>
      <button className="logoutBtn">Kijelentkezés</button>
    </div>
  );
};

export default Private;
