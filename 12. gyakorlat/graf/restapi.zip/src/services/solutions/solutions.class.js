const { Service } = require("feathers-sequelize");

exports.Solutions = class Solutions extends Service {};
