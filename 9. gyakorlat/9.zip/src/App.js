import Login from "./Login";
import Private from "./Private";

function App() {
  return (
    <div>
      <Login />
      <Private />
    </div>
  );
}

export default App;
